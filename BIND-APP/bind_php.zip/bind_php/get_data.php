<?php
header('Content-Type: application/json');


include 'db_connection.php';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_POST['user_id'];


    $sql = "SELECT id, mood, data, date FROM data WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();


    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }


    echo json_encode([
        "status" => true,
        "message" => "Journal entries retrieved successfully.",
        "data" => $data
    ]);


    $stmt->close();
}
$conn->close();
?>
