<?php
header('Content-Type: application/json');
include 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['user_id']) || empty($_POST['user_id'])) {
        echo json_encode([
            "status" => false,
            "message" => "User ID is missing.",
            "data" => []
        ]);
        exit();
    }

    $user_id = intval($_POST['user_id']);

    if (!$conn) {
        echo json_encode([
            "status" => false,
            "message" => "Database connection failed.",
            "data" => []
        ]);
        exit();
    }

    $sql = "SELECT id, title, description, event_date, priority FROM events WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        echo json_encode([
            "status" => false,
            "message" => "SQL prepare failed.",
            "data" => []
        ]);
        exit();
    }

    $stmt->bind_param('i', $user_id);
    
    if (!$stmt->execute()) {
        echo json_encode([
            "status" => false,
            "message" => "SQL execution failed: " . $stmt->error,
            "data" => []
        ]);
        exit();
    }

    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $events = [];

        while ($row = $result->fetch_assoc()) {
            $events[] = [
                "id" => $row["id"],
                "title" => $row["title"],
                "description" => $row["description"],
                "event_date" => $row["event_date"],
                "priority" => $row["priority"]
            ];
        }

        echo json_encode([
            "status" => true,
            "message" => "Events fetched successfully.",
            "data" => $events
        ]);
    } else {
        echo json_encode([
            "status" => false,
            "message" => "No events found for the user.",
            "data" => []
        ]);
    }

    $stmt->close();
}
$conn->close();
?>
