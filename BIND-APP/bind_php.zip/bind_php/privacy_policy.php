<?php

// Function to display the privacy policy content
function display_privacy_policy() {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy - BIND</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: #fff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h1, h2 {
            color: #d9534f;
        }
        p {
            color: #555;
        }
        ul {
            padding-left: 20px;
        }
        a {
            color: #007bff;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Privacy Policy - BIND</h1>
        <p><strong>Welcome to BIND. Your privacy is important to us, and we are committed to protecting your personal data. This Privacy Policy explains how we collect, use, and secure your information.</strong></p>

        <h2>1. Information We Collect</h2>
        <p>We collect different types of data to provide and improve our services. This includes:</p>
        <ul>
            <li><strong>Personal Information:</strong> When you create an account, we collect your name, email address, phone, dob and username.</li>
            <li><strong>Usage Data:</strong> Information about how you interact with our app, such as features you use, time spent on the app, and preferences.</li>
        </ul>

        <h2>2. How We Use Your Data</h2>
        <p>Your data is used to:</p>
        <ul>
            <li>Provide and maintain our services.</li>
            <li>Personalize your experience by suggesting journal prompts or analyzing sentiment.</li>
            <li>Ensure security and detect unauthorized access.</li>
            <li>Improve app performance and develop new features.</li>
        </ul>

        <h2>3. Data Security</h2>
        <p>We take appropriate security measures to protect your data, including encryption, secure storage, and access controls. However, no method of transmission over the internet is 100% secure.</p>

        <h2>4. Cookies & Tracking Technologies</h2>
        <p>We may use cookies or similar tracking technologies to enhance your experience, remember preferences, and analyze traffic. You can disable cookies in your browser settings, but some features may not function properly.</p>
        <h2>5. Data Sharing & Disclosure</h2>
        <p>We do not sell or rent your personal information. However, we may share data in the following cases:</p>
        <ul>
            <li><strong>Legal Compliance:</strong> If required by law, we may disclose your information to authorities.</li>
            <li><strong>Service Providers:</strong> Trusted third-party services that assist us in providing app functionalities (e.g., cloud storage).</li>
            <li><strong>Business Transfers:</strong> In case of a merger or acquisition, user data may be transferred.</li>
        </ul>

        <h2>6. Your Rights & Choices</h2>
        <p>As a user, you have the right to:</p>
        <ul>
            <li>Access, update, or delete your personal data.</li>
            <li>Request a copy of your data.</li>
            <li>Withdraw consent for data processing.</li>
        </ul>
        <p>You can manage your data preferences within the app settings or contact us for assistance.</p>

        <h2>7. Data Retention</h2>
        <p>Your personal data and journal entries are retained as long as you use our services. If you delete your account, all associated data will be permanently erased from our servers.</p>

        <h2>8. Changes to This Policy</h2>
        <p>We may update this Privacy Policy from time to time. Any changes will be communicated within the app or via email.</p>

        <h2>9. Contact Us</h2>
        <p>If you have any questions regarding this Privacy Policy, feel free to reach out to us:</p>
        <p>Email: <a href="mailto:hemanthkonathala2004@gmail.com">BIND</a></p>

        <p>© 2025 BIND. All rights reserved.</p>
    </div>
</body>
</html>
<?php
}

// Call the function to display the privacy policy
display_privacy_policy();
?>
