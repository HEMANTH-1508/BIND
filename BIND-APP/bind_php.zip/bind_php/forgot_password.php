<?php
header('Content-Type: application/json');
include 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($_POST['email']) || empty($_POST['dob'])) {
        echo json_encode([
            "status" => false,
            "message" => "Email and date of birth are required.",
            "data" => []
        ]);
        exit();
    }

    $email = trim($_POST['email']);
    $dob = trim($_POST['dob']);

    if (!$conn) {
        echo json_encode([
            "status" => false,
            "message" => "Database connection failed.",
            "data" => []
        ]);
        exit();
    }

    $sql = "SELECT id, username, email, dob FROM users WHERE email = ? AND dob = ?";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        echo json_encode([
            "status" => false,
            "message" => "SQL prepare failed.",
            "data" => []
        ]);
        exit();
    }

    $stmt->bind_param("ss", $email, $dob);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $username, $email_db, $dob_db);
        $stmt->fetch();

        echo json_encode([
            "status" => true,
            "message" => "User verified successfully.",
            "data" => [
                "id" => $id,
                "username" => $username,
                "email" => $email_db,
                "dob" => $dob_db
            ]
        ]);
    } else {
        echo json_encode([
            "status" => false,
            "message" => "No matching user found.",
            "data" => []
        ]);
    }

    $stmt->close();
}
$conn->close();
?>
