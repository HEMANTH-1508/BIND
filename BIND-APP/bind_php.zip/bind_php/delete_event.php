<?php
header('Content-Type: application/json');

include 'db_connection.php';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data_id = $_POST['event_id'];


    $sql = "DELETE FROM events WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $data_id);


    if ($stmt->execute()) {
        echo json_encode([
            "status" => true,
            "message" => "Event deleted successfully.",
            "data" => []
        ]);
    } else {
        echo json_encode([
            "status" => false,
            "message" => "Error deleting event.",
            "data" => []
        ]);
    }


    $stmt->close();
}
$conn->close();
?>
