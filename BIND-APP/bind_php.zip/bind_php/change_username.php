<?php
header('Content-Type: application/json');
include 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_POST['user_id'] ?? null;
    $old_username = $_POST['old_username'] ?? null;
    $new_username = $_POST['new_username'] ?? null;

    if (!$user_id || !$old_username || !$new_username) {
        echo json_encode([
            "status" => false,
            "message" => "All fields are required."
        ]);
        exit;
    }

    $sql = "SELECT id FROM users WHERE id = ? AND username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $user_id, $old_username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 0) {
        echo json_encode([
            "status" => false,
            "message" => "Old username is incorrect."
        ]);
        exit;
    }
    $stmt->close();

    $check_sql = "SELECT id FROM users WHERE username = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("s", $new_username);
    $check_stmt->execute();
    $check_stmt->store_result();

    if ($check_stmt->num_rows > 0) {
        echo json_encode([
            "status" => false,
            "message" => "Username is already taken. Please choose another one."
        ]);
        exit;
    }
    $check_stmt->close();

    $update_sql = "UPDATE users SET username = ? WHERE id = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("si", $new_username, $user_id);

    if ($update_stmt->execute()) {
        echo json_encode([
            "status" => true,
            "message" => "Username updated successfully."
        ]);
    } else {
        echo json_encode([
            "status" => false,
            "message" => "Failed to update username. Please try again."
        ]);
    }

    $update_stmt->close();
    $conn->close();
}
?>
