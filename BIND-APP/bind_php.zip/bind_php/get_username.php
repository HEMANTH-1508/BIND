<?php
header("Content-Type: application/json");
include "db_connection.php"; 
$response = ["status" => false, "username" => ""];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $userId = isset($_POST["user_id"]) ? intval($_POST["user_id"]) : 0;

    if ($userId > 0) {
        $query = "SELECT username FROM users WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $stmt->bind_result($username);
        
        if ($stmt->fetch()) {
            $response["status"] = true;
            $response["username"] = $username;
        }
        
        $stmt->close();
    }
}

echo json_encode($response);
$conn->close();
?>
