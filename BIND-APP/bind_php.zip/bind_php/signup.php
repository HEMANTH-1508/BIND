<?php
header('Content-Type: application/json');


include 'db_connection.php';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $dob = $_POST['dob'];


    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !preg_match('/\.com$/', $email)) {
        echo json_encode([
            "status" => false,
            "message" => "Invalid email format.",
            "data" => []
        ]);
        exit();
    }

    if ($password !== $confirm_password) {
        echo json_encode([
            "status" => false,
            "message" => "Passwords do not match.",
            "data" => []
        ]);
        exit;
    }


    $sql_check = "SELECT * FROM users WHERE username = ? OR email = ?";
    $stmt_check = $conn->prepare($sql_check);
    $stmt_check->bind_param("ss", $username, $email);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();


    if ($result_check->num_rows > 0) {
        echo json_encode([
            "status" => false,
            "message" => "Username or email already exists.",
            "data" => []
        ]);
        $stmt_check->close();
        exit;
    }


    $sql = "INSERT INTO users (username, email, password, dob) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $username, $email, $password, $dob);


    if ($stmt->execute()) {
        echo json_encode([
            "status" => true,
            "message" => "User registered successfully.",
            "data" => [
                [
                    "id" => $conn->insert_id,
                    "username" => $username,
                    "email" => $email,
                    "dob" => $dob
                ]
            ]
        ]);
    } else {
        echo json_encode([
            "status" => false,
            "message" => "Error: " . $stmt->error,
            "data" => []
        ]);
    }


    $stmt->close();
}
$conn->close();
?>
