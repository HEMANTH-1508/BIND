<?php
header('Content-Type: application/json');
include 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($_POST['email']) || empty($_POST['password'])) {
        echo json_encode([
            "status" => false,
            "message" => "Email and password are required.",
            "data" => []
        ]);
        exit();
    }

    $email = trim($_POST['email']);
    $password = trim($_POST['password']);


    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !preg_match('/\.com$/', $email)) {
        echo json_encode([
            "status" => false,
            "message" => "Invalid email format.",
            "data" => []
        ]);
        exit();
    }

    if (!$conn) {
        echo json_encode([
            "status" => false,
            "message" => "Database connection failed.",
            "data" => []
        ]);
        exit();
    }

    $sql = "SELECT id, username, email FROM users WHERE email = ? AND password = ?";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        echo json_encode([
            "status" => false,
            "message" => "SQL prepare failed.",
            "data" => []
        ]);
        exit();
    }

    $stmt->bind_param("ss", $email, $password);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $username, $email_db);
        $stmt->fetch();

        echo json_encode([
            "status" => true,
            "message" => "Login successful.",
            "data" => [
                "id" => $id,
                "username" => $username,
                "email" => $email_db
            ]
        ]);
    } else {
        echo json_encode([
            "status" => false,
            "message" => "Invalid email or password.",
            "data" => []
        ]);
    }

    $stmt->close();
}
$conn->close();
?>
