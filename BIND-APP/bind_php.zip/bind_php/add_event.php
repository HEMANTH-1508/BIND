<?php
header('Content-Type: application/json');


include 'db_connection.php';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_POST['user_id'];
    $title = $_POST['title'];
    $description = $_POST['description'];
    $event_date = $_POST['event_date'];
    $priority = $_POST['priority'];


    $sql = "INSERT INTO events (user_id, title, description, event_date, priority) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("issss", $user_id, $title, $description, $event_date, $priority);


    if ($stmt->execute()) {
        echo json_encode([
            "status" => true,
            "message" => "Event added successfully.",
            "data" => [
                [
                    "id" => $conn->insert_id,
                    "title" => $title,
                    "priority" => $priority
                ]
            ]
        ]);
    } else {
        echo json_encode([
            "status" => false,
            "message" => "Error: " . $stmt->error,
            "data" => []
        ]);
    }


    $stmt->close();
}
$conn->close();
?>
