<?php
header('Content-Type: application/json');
include 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_POST['user_id'];
    $old_password = $_POST['old_password'];
    $new_password = $_POST['new_password'];

    if (empty($user_id) || empty($old_password) || empty($new_password)) {
        echo json_encode([
            "status" => false,
            "message" => "All fields are required."
        ]);
        exit;
    }

    // Fetch current password from database
    $sql = "SELECT password FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($stored_password);
        $stmt->fetch();

        // Check if old password matches
        if ($old_password === $stored_password) {
            // Update the password
            $update_sql = "UPDATE users SET password = ? WHERE id = ?";
            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("si", $new_password, $user_id);

            if ($update_stmt->execute()) {
                echo json_encode([
                    "status" => true,
                    "message" => "Password updated successfully."
                ]);
            } else {
                echo json_encode([
                    "status" => false,
                    "message" => "Error updating password."
                ]);
            }
            $update_stmt->close();
        } else {
            echo json_encode([
                "status" => false,
                "message" => "Old password is incorrect."
            ]);
        }
    } else {
        echo json_encode([
            "status" => false,
            "message" => "User not found."
        ]);
    }

    $stmt->close();
}

$conn->close();
?>
