<?php
header('Content-Type: application/json');
include 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $dob = $_POST['dob'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    if ($new_password !== $confirm_password) {
        echo json_encode([
            "status" => false,
            "message" => "Passwords do not match."
        ]);
        exit;
    }

    $sql = "SELECT id FROM users WHERE email = ? AND dob = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $email, $dob);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $update_sql = "UPDATE users SET password = ? WHERE email = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("ss", $new_password, $email);

        if ($update_stmt->execute()) {
            echo json_encode([
                "status" => true,
                "message" => "Password changed successfully."
            ]);
        } else {
            echo json_encode([
                "status" => false,
                "message" => "Error updating password."
            ]);
        }

        $update_stmt->close();
    } else {
        echo json_encode([
            "status" => false,
            "message" => "Invalid email or date of birth."
        ]);
    }

    $stmt->close();
}
$conn->close();
?>
