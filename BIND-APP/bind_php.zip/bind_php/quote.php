<?php
header('Content-Type: application/json');


include 'db_connection.php';


if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $sql = "SELECT quote, author FROM quotes ORDER BY RAND() LIMIT 1";
   
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $stmt->store_result();


    if ($stmt->num_rows > 0) {
        $stmt->bind_result($quote, $author);
        $stmt->fetch();


        echo json_encode([
            "status" => true,
            "message" => "Random quote fetched successfully.",
            "data" => [
                "quote" => $quote,
                "author" => $author
            ]
        ]);
    } else {
        echo json_encode([
            "status" => false,
            "message" => "No quotes found.",
            "data" => []
        ]);
    }


    $stmt->close();
}
$conn->close();
?>
