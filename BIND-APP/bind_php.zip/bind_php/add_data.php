<?php
header('Content-Type: application/json');


include 'db_connection.php';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_POST['user_id'];
    $mood = $_POST['mood'];
    $data = $_POST['data'];


    $sql = "INSERT INTO data (user_id, mood, data) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iss", $user_id, $mood, $data);


    if ($stmt->execute()) {
        $last_id = $conn->insert_id;


        $retrieve_sql = "SELECT id, mood, data, date FROM data WHERE id = ?";
        $retrieve_stmt = $conn->prepare($retrieve_sql);
        $retrieve_stmt->bind_param("i", $last_id);


        if ($retrieve_stmt->execute()) {
            $result = $retrieve_stmt->get_result();
            $row = $result->fetch_assoc();


            echo json_encode([
                "status" => true,
                "message" => "Data added successfully.",
                "data" => [
                    [
                        "id" => $row['id'],
                        "mood" => $row['mood'],
                        "data" => $row['data'],
                        "date" => $row['date']
                    ]
                ]
            ]);
        } else {
            echo json_encode([
                "status" => false,
                "message" => "Error retrieving data: " . $retrieve_stmt->error,
                "data" => []
            ]);
        }


        $retrieve_stmt->close();
    } else {
        echo json_encode([
            "status" => false,
            "message" => "Error: " . $stmt->error,
            "data" => []
        ]);
    }


    $stmt->close();
}
$conn->close();
?>
