<?php
header('Content-Type: application/json');


include 'db_connection.php';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data_id = $_POST['data_id'];


    $sql = "DELETE FROM data WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $data_id);


    if ($stmt->execute()) {
        echo json_encode([
            "status" => true,
            "message" => "Journal entry deleted successfully.",
            "data" => []
        ]);
    } else {
        echo json_encode([
            "status" => false,
            "message" => "Error deleting journal entry.",
            "data" => []
        ]);
    }


    $stmt->close();
}
$conn->close();
?>
