<?php
header('Content-Type: application/json');
include 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_POST['user_id'] ?? null;
    $email = $_POST['email'] ?? null;
    $password = $_POST['password'] ?? null;

    if (!$user_id || !$email || !$password) {
        echo json_encode([
            "status" => false,
            "message" => "All fields are required.",
            "data" => []
        ]);
        exit;
    }

    $sql = "SELECT password FROM users WHERE id = ? AND email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $user_id, $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($stored_password);
        $stmt->fetch();

        if ($password === $stored_password) {
            $delete_sql = "DELETE FROM users WHERE id = ? AND email = ?";
            $delete_stmt = $conn->prepare($delete_sql);
            $delete_stmt->bind_param("is", $user_id, $email);

            if ($delete_stmt->execute()) {
                echo json_encode([
                    "status" => true,
                    "message" => "Account deleted successfully.",
                    "data" => []
                ]);
            } else {
                echo json_encode([
                    "status" => false,
                    "message" => "Error deleting account.",
                    "data" => []
                ]);
            }
            $delete_stmt->close();
        } else {
            echo json_encode([
                "status" => false,
                "message" => "Incorrect password.",
                "data" => []
            ]);
        }
    } else {
        echo json_encode([
            "status" => false,
            "message" => "Account not found.",
            "data" => []
        ]);
    }

    $stmt->close();
    $conn->close();
}
?>
